﻿/*
 *  Copyright (C) 2018 E7mer of PegasusTeam <haimohk@gmail.com>
 *
 *  This file is a part of GhostTunnel
 *
*/
#ifndef _OS_FUNC_H_
#define _OS_FUNC_H_
#include <windows.h>

DWORD get_computer_name(char *name_buf, DWORD *length);


#endif
