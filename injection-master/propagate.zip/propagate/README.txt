This is only a PoC.
The code doesn't perform error checking and could potentially be unstable.
Use at your own risk :P